package aprendendoTestar.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Page {

	WebDriver driver;

	public void openSite(String site, String navegador, String descricaoDoPasso) {

		switch (navegador) {

		case "Chrome":
			System.setProperty("webdriver.chrome.driver", "C:\\Driver\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(35, TimeUnit.SECONDS);
			driver.get(site);

			break;

		case "FireFox":
			System.setProperty("webdriver.gecko.driver", "C:\\Driver\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(35, TimeUnit.SECONDS);
			driver.get(site);

			break;
		}
	}

	public void cadastrarUsuario(String user, String senha, String nome, String descricaoDoPasso) {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.name("form_usuario")).sendKeys(user);
		driver.findElement(By.name("form_senha")).sendKeys(senha);
		driver.findElement(By.name("form_nome")).sendKeys(nome);
		driver.findElement(By.cssSelector(
				"body > section > section.wrapper > div > form > table > tbody > tr:nth-child(7) > td > input"))
				.click();

	}

	public void fecharBroser() {
		driver.quit();
	}

}
