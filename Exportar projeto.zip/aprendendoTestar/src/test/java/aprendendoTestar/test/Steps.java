package aprendendoTestar.test;

import aprendendoTestar.pages.Page;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps {
	
	Page p = new Page();

	@Given("^que eu acesso o site \"([^\"]*)\" e \"([^\"]*)\"$")
	public void que_eu_acesso_o_site_e(String arg1, String arg2) throws Throwable {
	    p.openSite(arg1, arg2, "acessando o site");
	}

	@When("^digitar  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  corretamente$")
	public void digitar_corretamente(String arg1, String arg2, String arg3) throws Throwable {
	    p.cadastrarUsuario(arg1, arg2, arg3, "preenchendo o cadastro");
	}
	

	@Then("^eu terei sucesso em meu cadastro$")
	public void eu_terei_sucesso_em_meu_cadastro() throws Throwable {
	    System.out.println("****Cadastro feito com sucesso****");
	    p.fecharBroser();
	}


}
